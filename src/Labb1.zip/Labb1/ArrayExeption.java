package Labb1;

public class ArrayExeption extends Exception { //Tack för tipset till denna metod Lars! :) Mycket användbar.
    public ArrayExeption (String exMsg) {
        super (exMsg);
    }
}