package Labb2;

import java.util.Date;

public class PurchaseStore implements IPurchaseStore {

    @Override
    public Purchase[] getPurchases(Date startDate, Date endDate) {
        return null;
    }

    @Override
    public Purchase[] getPurchasesByCategory(Date startDate, Date endDate, int catId) {
        return null;
    }

    @Override
    public Category[] getAllCategories() {
        return null;
    }
}
